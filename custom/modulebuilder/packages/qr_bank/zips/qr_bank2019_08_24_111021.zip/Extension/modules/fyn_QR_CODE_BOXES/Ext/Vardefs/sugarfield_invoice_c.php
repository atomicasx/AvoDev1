<?php
 // created: 2019-08-17 13:04:49
$dictionary['fyn_QR_CODE_BOXES']['fields']['invoice_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_BOXES']['fields']['invoice_c']['labelValue']='Invoice';

 ?>