<?php
 // created: 2019-08-17 13:06:05
$dictionary['fyn_QR_CODE_BOXES']['fields']['driver_name_c']['inline_edit']='1';
$dictionary['fyn_QR_CODE_BOXES']['fields']['driver_name_c']['labelValue']='Driver Name';

 ?>