<?php 
 // created: 2019-08-24 11:10:13
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_FYN_QR_CODE_BOXES_FYN_STOCK_IN_1_FROM_FYN_STOCK_IN_TITLE'] = 'Stock In';
$mod_strings['LBL_FYN_QR_CODE_BOXES_FYN_STOCK_OUT_1_FROM_FYN_STOCK_OUT_TITLE'] = 'Stock Out';
$mod_strings['LBL_FYN_QR_CODE_BOXES_VS_VEHICLESTOCKOUT_1_FROM_VS_VEHICLESTOCKOUT_TITLE'] = 'Vehicle StockOUT';
$mod_strings['LNK_NEW_RECORD'] = 'Create QR Bank';
$mod_strings['LNK_LIST'] = 'View QR Bank';
$mod_strings['LNK_IMPORT_FYN_QR_CODE_BOXES'] = 'Import QR Bank';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'QR Bank List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search QR Bank';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My QR Bank';
$mod_strings['LBL_DRIVER_NAME_USER_ID'] = 'Driver Name (related User ID)';
$mod_strings['LBL_DRIVER_NAME'] = 'Driver Name';
$mod_strings['LBL_INVOICE_AOS_INVOICES_ID'] = 'Invoice (related  ID)';
$mod_strings['LBL_INVOICE'] = 'Invoice';

?>
