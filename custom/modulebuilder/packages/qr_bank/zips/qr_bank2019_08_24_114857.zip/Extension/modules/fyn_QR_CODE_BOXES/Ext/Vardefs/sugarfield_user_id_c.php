<?php
 // created: 2019-08-17 12:52:13
$dictionary['fyn_QR_CODE_BOXES']['fields']['user_id_c']['inline_edit']=1;

 ?>